// Initialize app
//var myApp = new Framework7();

// If we need to use custom DOM library, let's save it to $$ variable:
var $$ = Dom7;
var app = new Framework7({
    // App root element
    root: '#app',
    // App Name
    name: 'My App',
    // App id
    id: 'com.myapp.test',
    // Enable swipe panel
    panel: {
      swipe: 'left',
    },
    // Add default routes
    routes: [
      {
        path: '/about/',
        url: 'about.html',
      },
      {
        path: '/consumos/',
        url: 'consumos.html',
      },
      {
        path: '/historial/',
        url: 'historial.html',
      },
    ]
    // ... other parameters
  });
/*[Functions & variables GLOBALES]============================================*/
// Variable de asignacion preDefinida por ingreso en consumos/gastos:
var id = parseInt(localStorage.getItem('id')); // Extrae los datos de consola.
if (isNaN(id)) {
  console.log("[<AVISO: Condicional isNaN(id) accionado.]"); // DEBUGGING
  id=0;
  console.log("");
}
// Funciones:-------------------------------------------------------------------
function deleteID(Nid){
  /*
  Nombre: delete
  Signatura: number -> none
  Funcion: Recibe como parametro un numero entero, el cual sirve como ID de referencia, y se eliminara el valor asociado a ese id del localStorage.
  */
  console.log("<AVISO: Funcion deleteID accionada.>"); // DEBUGGING
  // Borrar un dato de localStorage:
  localStorage.removeItem(Nid);
  //alert("Ultimo elemento ingresado eliminado.");
}// Fin delete.
// -----------------------------------------------------------------------------
function obtenerFecha(){
  /*
  Nombre: obtenerFecha
  Signatura: none -> string
  Funcion: Extrae la fecha del sistema.
  */
  console.log("<AVISO: Funcion obtenerFecha accionada.>"); // DEBUGGING
  // Declaracion de variables: Numbers ->
  var f = new Date();
  var dia = f.getDate();
  var mes = (f.getMonth()+1);
  var a= f.getFullYear();
  var hoy = dia+"/"+mes+"/"+a
  // Valor de salida:
  console.log(hoy); // DEBUGGING
  return hoy;
}
// -----------------------------------------------------------------------------
function generarHistorial(Nid,monto){
  console.log("<AVISO: Funcion generar historial accionada.>"); // DEBUGGING
  if(!(isNaN(id) && isNaN(monto))){
    /*
    Nombre: generarHistorial
    Signatura: none -> none
    Funcion: No recibe ningun dato como parametro ni entrega otro.
    Su funcion principal es generar registros, en el html, sobre los Consumos
    ingresados por el usuario.
    */
    // createElement: crear elementos dentro del DOM.
    // classList: usados para agregar clases a los elementos generados.
    // removeChild: elimina elementos de un html de forma dinamica.
    // GENERAR HTML:
    // Declaracion de variables:
    var div = document.createElement("div"); // Crear div
    var p = document.createElement("p"); // Crear texto plano
    var p2 = document.createElement("p"); // Crear texto plano
    var hr =  document.createElement("hr"); // Crear linea divisora
    // Ubicar contenido dentro del id: add
    var addDoc = document.getElementById("contenedorHistorial");
    var addDocDiv = addDoc.appendChild(div); // Agrega: div al contenedorHistorial
    // Combinar elementos generados:
    var addDocDivP = addDocDiv.appendChild(p);
    var addDocDivP2 = addDocDiv.appendChild(p2);
    var montoAnterior = Nid-1
    var valorIngresado = monto - parseInt(localStorage.getItem(montoAnterior));
    if (isNaN(valorIngresado)){
      valorIngresado=monto;
    }
    if (isNaN(monto)){
      valorIngresado=0;
    }
    // Añadir texto al DOM:
    addDocDivP.innerHTML = "I.D.: "+Nid+"  |  Consumo acumulado: $"+monto; // Dentro de divP: Title
    addDocDivP2.innerHTML = "Consumo: $ "+valorIngresado+" "; // Dentro de divP: Title
    addDocDivP2.appendChild(hr);
    console.log("Nuevo registro generado.");
  } // End if.
} // End function: generarHistorial
//==============================================================================
var mainView = app.views.create('.view-main');
//==============================================================================
// Handle Cordova Device Ready Event
//==============================================================================
$$(document).on('deviceready', function() {
  console.log("Wirtschaft is ready!");
});
//==============================================================================
// Option 1. Using one 'page:init' handler for all pages
$$(document).on('page:init', function (e) {
    //==============================================================================
    // Datos iniciales:                            [AutoEjecutados al iniciar index]
    //==============================================================================
    // Do something here when page loaded and initialized
    console.log(e);
    console.log("Wirtschaft is ready!");
    // Traemos la variable guardada en localstorage
    var acumulado = parseInt(localStorage.getItem('gasto'));
    var id = parseInt(localStorage.getItem('id'));
    console.log("ID = "+id);
    console.log("Acumulado = "+acumulado);
    // Nivelador de valores residuales:
    if(acumulado==0 || id==0 || acumulado==null || id==null){
      localStorage.setItem('gasto', 0);
      localStorage.setItem('id', 0);
      console.log("if nivelador de valores residuales, activado.");
    }
    /* Si la variable no existe el navegador o dispositivo puede devolver uno de tres valores: null, undefined o cadena vacía,
    por lo que preguntamos si el valor de la variable no es ninguno de los tres, lo mostramos en pantalla. */
    if (acumulado != null && acumulado != undefined && acumulado != "" ) {
      // Mostramos el dato guardado en el span con id salida
      $$('#salida').text(acumulado);
      console.log("if null activado");
    }
    /* Si la variable no existe el navegador o dispositivo puede devolver uno de tres valores: null, undefined o vacío,
    por lo que preguntamos si el valor de la variable no es ninguno de los tres, lo mostramos en pantalla. */
    if (id != null && id != undefined && id <= 0 ) {
      // Mostramos el dato guardado en el span con id salida
      id=0;
      console.log("if id=0 activado");
    }
    // Bucle de repeticion definido: utilizado para generar historial de ingresos
    for (var i = id; i > 0; i--) {
      if (id>0 && acumulado>0){
        console.log(i+") Generar historial iniciado.");
        var gastoAsociado = localStorage.getItem(i);
        generarHistorial(i,gastoAsociado);
      }
    }
    console.log("");

    //==============================================================================
    // Interacciones del boton:                                            [guardar]
    //==============================================================================
    $$('#guardar').on('click', function() {
      console.log("|AVISO:| Boton guardar accionado."); // DEBUGGING
      /* Lo primero que hacemos es verificar que haya algo en el input, sino traeremos una cadena vacía que al tratarla como número nos dará NaN (not a Number). */
      if ($$('#gasto').val() != ""){
        // Declaracion de variables:
        // Al agregar uno al id cambiamos el valor de nombre key utilizado en el almacenamiento de informacion.
        id +=1; // aumento el valor de id mas uno.
        console.log("Asignacion de Id: -> ["+id+"]"); // DEBUGGING
        /* Traemos el importe del gasto y lo convertimos a número (aunque sea un input de tipo number el ingreso siempre es string) por medio de la función parseFloat()
        que nos devuelve un número flotante (por si el gasto tiene decimales). */
        var gasto = parseFloat($$('#gasto').val());
        console.log("Valor de gasto:   -> ["+gasto+"]"); // DEBUGGING
        /* Traemos el importe actual que figura en el span y lo convertimos a número (es string). */
        var actual = parseFloat($$('#salida').text());
        console.log("Valor de actual:  -> ["+actual+"]"); // DEBUGGING
        // Estructura de control: if
        /* Si actual tiene valor NaN (not a number), significa que no tenemos ningún valor guardado sino que era un texto que no pudo convertir a número,
        por lo tanto éste valor ingresado en el input es el primer valor, entonces,  lo asignamos directamente. En cambio si no es NaN ya tenemos un valor numérico en pantalla,
        por lo tanto, hay que sumar el nuevo gasto al acumulado. */
        if ( isNaN(actual) ) {
          console.log("Valor "+gasto+" NaN, asignado."); // DEBUGGING
          /* Si no había nada, el gasto ingresado es directamente el que mostramos. */
          $$('#salida').text(gasto);
          // Y lo guardamos localmente para no perderlo.
          localStorage.setItem('gasto', gasto);
          localStorage.setItem('id', id);
          localStorage.setItem(id, gasto);
          // Limpiamos el input para un nuevo ingreso.
          $$('#gasto').val("");
        } // fin de if anidado.
        else {
          // Si había un nro guardado, sumamos el gasto ingresado al actual.
          actual += gasto;
          console.log("Suma de gasto actual y dato ingresado realizada."); // DEBUGGING
          console.log("-->> nuevo [ACTUAL = "+actual+"]"); // DEBUGGING
          console.log(" ");
          // Mostramos en el span el nuevo valor acumulado
          $$('#salida').text(actual);
          /* Y guardamos localmente el resultado para no perderlo. */
          localStorage.setItem('gasto', actual);
          localStorage.setItem('id', id);
          localStorage.setItem(id, actual);
          // Limpiamos el input para un nuevo ingreso.
          $$('#gasto').val("");
        } // fin de else anidado.
      alert("Registro añadido!");
      } // fin de if principal.
      else {
        /* Si el campo está vacío al presionar el botón guardar, mostramos un cartel de error. */
        alert("Ingrese un valor numerico");
        console.log("AVISO: Valores inalterados.");
      } // fin de else principal.
      console.log("");
    });
    //==============================================================================
    // Interacciones del boton:                                    [Deshacer ultimo]
    //==============================================================================
    $$('#borrarUltimo').on('click', function() {
      console.log("|AVISO:| Boton deshacer accionado."); // DEBUGGING
      // Determina si eliminar, o no, el ultimo ingreso: (pregunta al usuario)
      if (window.confirm("Desea eliminar el ultimo ingreso?")){
        // Declaracion de variables:
        var tempGasto = localStorage.getItem('gasto');
        var extraerID = id; // Extrae el id mas alto ingresado. (MODIFICADO CON EL ID GLOBAL)
        var extraerMonto = localStorage.getItem(extraerID);
        console.log("|Ultimo gasto   -> ["+tempGasto+"]|"); // DEBUGGING
        console.log("|ID asociado    -> ["+extraerID+"]|"); // DEBUGGING
        console.log("|Monto asociado -> ["+extraerMonto+"]|"); // DEBUGGING
        // En caso de existir ausencia de datos numericos nivelar base de datos:
        if (extraerMonto==null || extraerID==null || id==0 || gasto==0){
          // Modificacion de variables:
          extraerMonto=0;
          extraerID=0;
          // Eliminar errores de almacenamiento reiniciando valores:
          localStorage.setItem('id',0);
          localStorage.setItem('gasto',0);
          console.log("CAMINO NULL ACTIVADO");
          console.log("Valor de gasto   -> "+localStorage.getItem('gasto')+"|"); // DEBUGGING
          console.log("Valor de id      -> "+localStorage.getItem('id')+"|"); // DEBUGGING
        }// Fin de if auxiliar I.
        // Solo borrar el ultimo elemento si existen id iguales o mayores a 1. (El valor de id representa la cantidad de ingresos efectuados)
        if (extraerID >= 1){
          // Funcion de eliminar valor almacenado:
          deleteID(extraerID);
          console.log("Eliminacion exitosa!"); // DEBUGGING
          // Disminuir el valor de ID maximo en 1 solo si id es mayor a 0:
          if (id>0){
            id-=1;
            console.log("ID - 1 = "+id); // DEBUGGING
          }
          // Setear nuevo valor en caso de id mayor a 0:
          if (id>0){
            localStorage.setItem('id',id);
            console.log("Valor de id NUEVO-> "+localStorage.getItem('id')+"|"); // DEBUGGING
          }
          // Setear id a cero en caso de ser cero: (Seguro de elemento final, funcion redundante.)
          if (id==0){
            localStorage.setItem('id',0);
            console.log("Valor de id RESET -> "+localStorage.getItem('id')+"|"); // DEBUGGING
          }
          // Variable auxiliar: extrae el nuevo monto "maximo" resultando de la eliminacion del anterior maximo:
          var nuevoMonto = localStorage.getItem(id);
          // Y mostramos el nuevo monto en el span:
          if (nuevoMonto==null) {
            // en caso de nuevoMonto ser null, equivaler a cero:
            $$('#salida').text(0);
            id=0;
            localStorage.setItem('gasto',0);
            console.log("Valor gasto RESET -> "+localStorage.getItem('gasto')+"|"); // DEBUGGING
          } // Fin de if auxiliar II anidado
          else {
            $$('#salida').text(nuevoMonto);
            localStorage.setItem('gasto',nuevoMonto);
          } // Fin de else auxiliar II anidado
        } // Fin de if auxiliar II
        console.log("");
      }
    });
    //==============================================================================
    // Interacciones del boton:                        [Limpiar todos los registros]
    //==============================================================================
    $$('#limpiar').on('click', function() {
      console.log("");
      console.log("|AVISO:| Boton limpiar accionado."); // DEBUGGING
      if (window.confirm("Desea eliminar TODOS los datos guardados?")){
        // Limpiamos el localStorage.
        localStorage.clear();
        id=0;
        // Y mostramos el texto por default en el span.
        $$('#salida').text('0');
        alert("AVISO: Todos sus ingresos fueron eliminados.");
        console.log("AVISO: Base de datos eliminada.");
        console.log("");
      }
    });
})
//==============================================================================
